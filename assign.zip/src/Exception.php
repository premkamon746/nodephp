<?php namespace ClanCats\Station\PHPServer;

class Exception extends \Exception {}