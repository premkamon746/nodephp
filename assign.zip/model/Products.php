<?php
namespace Premkamon\DataModel;


class Products
{
	
}